# Torque Empire CRM
Deployed with flat structure for Vercel.